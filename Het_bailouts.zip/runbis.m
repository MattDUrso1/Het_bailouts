clear
close all

[agg_B, agg_C, agg_I, agg_K, agg_N, agg_Y, wss, mu] = bis();
css = agg_C;

save pfinputs